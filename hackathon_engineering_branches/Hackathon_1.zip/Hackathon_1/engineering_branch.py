#engineering_branch.py

import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
import os

def load_data(filepath):
    df = pd.read_csv(filepath)
    df['Enrolled'] = pd.to_numeric(df['Enrolled'], errors='coerce')
    df['Placed'] = pd.to_numeric(df['Placed'], errors='coerce')
    df['AvgSalary'] = pd.to_numeric(df['AvgSalary'], errors='coerce')
    df['PlacementRatio'] = df['Placed'] / df['Enrolled']
    return df

def create_pivots(df):
    return {
        'enroll': df.pivot(index='Year', columns='Branch', values='Enrolled'),
        'salary': df.pivot(index='Year', columns='Branch', values='AvgSalary'),
        'ratio': df.pivot(index='Year', columns='Branch', values='PlacementRatio'),
    }

def plot_enrollment(pivots, save_path=None): #save_path can save the plot to a file
    df = pivots['enroll']
    years = df.index
    branches = df.columns
    width = 0.1  # width of each bar in the bar chart
    x = np.arange(len(years))  # numeric positions for the x-axis, one per year
    plt.figure(figsize=(14, 6)) #14 inches wide × 6 inches tall
    for i, branch in enumerate(branches):
        plt.bar(x + i * width, df[branch], width, label=branch) #Plots bars for each year, slightly offset so that multiple branches don't overlap (x + i * width), uses branch name as a label.
    plt.title('Branch Enrollment Trends (Bar Graph)')
    plt.xlabel('Year')
    plt.ylabel('Students Enrolled')
    plt.xticks(x + width * len(branches) / 2, years)
    plt.legend()
    plt.grid(axis='y') #Adds horizontal grid lines
    plt.tight_layout() #adjusts the spacing between plot elements
    if save_path:
        plt.savefig(save_path)
        plt.close()
    else:
        plt.show()


def plot_salary(pivots, save_path=None):
    plt.figure(figsize=(12, 5))
    for branch in pivots['salary'].columns:
        plt.plot(pivots['salary'].index, pivots['salary'][branch], marker='s', linestyle='--', label=branch)
    plt.title('Average Salary Trend by Branch (LPA)')
    plt.xlabel('Year')
    plt.ylabel('Salary (LPA)')
    plt.legend()
    plt.grid(True)
    plt.tight_layout()
    if save_path:
        plt.savefig(save_path)
        plt.close()
    else:
        plt.show()

def plot_placement_ratio(pivots, save_path=None):
    plt.figure(figsize=(12, 5))
    for branch in pivots['ratio'].columns:
        plt.plot(pivots['ratio'].index, pivots['ratio'][branch], marker='^', label=branch)
    plt.title('Placement vs Enrollment Ratio by Branch')
    plt.xlabel('Year')
    plt.ylabel('Placement Ratio')
    plt.legend()
    plt.grid(True)
    plt.tight_layout()
    if save_path:
        plt.savefig(save_path)
        plt.close()
    else:
        plt.show()

def plot_pie(df, save_path=None): #enrollments for the latest year
    latest_year = df['Year'].max()
    latest_df = df[df['Year'] == latest_year]
    plt.figure(figsize=(8, 8))
    plt.pie(latest_df['Enrolled'], labels=latest_df['Branch'], autopct='%1.1f%%', startangle=140)
    plt.title(f'Enrollment Share by Branch in {latest_year}')
    plt.axis('equal')
    plt.tight_layout()
    if save_path:
        plt.savefig(save_path)
        plt.close()
    else:
        plt.show()

def get_summary(df):
    latest_year = df['Year'].max()
    latest_df = df[df['Year'] == latest_year]

    highest = latest_df.loc[latest_df['Enrolled'].idxmax()]
    lowest = latest_df.loc[latest_df['Enrolled'].idxmin()]
    salary = latest_df.loc[latest_df['AvgSalary'].idxmax()]
    best = latest_df.loc[latest_df['PlacementRatio'].idxmax()]
    worst = latest_df.loc[latest_df['PlacementRatio'].idxmin()]

    return {
        'year': latest_year,
        'highest_enrollment': (highest['Branch'], int(highest['Enrolled'])),
        'lowest_enrollment': (lowest['Branch'], int(lowest['Enrolled'])),
        'highest_salary': (salary['Branch'], salary['AvgSalary']),
        'best_ratio': (best['Branch'], round(best['PlacementRatio'], 2)),
        'worst_ratio': (worst['Branch'], round(worst['PlacementRatio'], 2))
    }
