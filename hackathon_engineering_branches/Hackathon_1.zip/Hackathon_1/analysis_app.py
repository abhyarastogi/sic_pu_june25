from flask import Flask, render_template, request
import os
from engineering_branch import *

data_file = 'engineering_branch_data.csv'
plot_folder = 'static/plots'

app = Flask(__name__)
os.makedirs(plot_folder, exist_ok=True)

@app.route('/', methods=['GET', 'POST'])
def index():
    summary = None
    plots = []
    options = request.form.getlist('option') if request.method == 'POST' else []

    if os.path.exists(data_file):
        df = load_data(data_file)
        pivots = create_pivots(df)

        if 'enrollment' in options:
            plot_enrollment(pivots, os.path.join(plot_folder, 'enrollment.png'))
            plots.append('enrollment.png')

        if 'salary' in options:
            plot_salary(pivots, os.path.join(plot_folder, 'salary.png'))
            plots.append('salary.png')

        if 'placement' in options:
            plot_placement_ratio(pivots, os.path.join(plot_folder, 'placement.png'))
            plots.append('placement.png')

        if 'pie' in options:
            plot_pie(df, os.path.join(plot_folder, 'pie.png'))
            plots.append('pie.png')

        if 'summary' in options:
            summary = get_summary(df)

    return render_template('index.html', plots=plots, summary=summary)

if __name__ == '__main__':
    app.run(debug=True, port = 5500)
